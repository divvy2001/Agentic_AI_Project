"""Black-box stdin/stdout checks against the saved, unchanged Monster Trio game."""
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from evaluation.terminal_runtime import run_terminal
from evaluation.records import tree_hashes
from evaluation.trials import atomic_json


def main(record):
    out = Path(record).resolve() / 'terminal'
    before = tree_hashes(out / 'game')
    plan = json.loads((out / 'plans/coder_plan.json').read_text(encoding='utf-8'))
    cases = {**{'choose_' + str(i): f'{i}\nquit\n' for i in (1, 2, 3)},
        'invalid': 'banana\n1\ninvalid-action\nquit\n',
        'special_exhaustion': '2\nspecial\nspecial\nspecial\nspecial\nquit\n',
        'win_replay': '1\nspecial\nspecial\nattack\nattack\nattack\ny\n1\nquit\n',
        'lose': '2\n' + 'defend\n' * 60 + 'attack\nn\n',
        'opponent_defense': '2\n' + 'attack\n' * 30 + 'n\n',
        'eof': ''}
    runs = {}
    for name, commands in cases.items():
        result = run_terminal(out, plan['architecture']['entry_point'], commands, timeout=15)
        runs[name] = result
        (out / (name + '.input.txt')).write_text(commands, encoding='utf-8')
        (out / (name + '.stdout.txt')).write_text(result.get('output', ''), encoding='utf-8')
        atomic_json(out / (name + '.runtime.json'), result)
    checks = []
    def check(name, requirement, value, evidence, actual):
        checks.append(dict(test_id=name, requirement_index=requirement, status='PASS' if value else 'FAIL',
                           evidence=evidence, actual=actual))
    healthy = all(r.get('status') == 'PASS' and r.get('returncode') == 0 for r in runs.values())
    check('actual_runtime', None, healthy, list(cases), 'Nine native sandboxed stdin/stdout sessions')
    for index, monster in enumerate(('Ignis', 'Aqua', 'Terra'), 1):
        text = runs['choose_' + str(index)].get('output', '')
        check('choose_' + str(index), 0, f'You chose {monster}.' in text,
              ['choose_' + str(index) + '.stdout.txt'], monster)
    text = runs['invalid'].get('output', '')
    check('invalid_input_does_not_advance_turn', 5,
          text.count('Invalid input.') == 2 and not re.search(r'for \d+ damage!', text),
          ['invalid.stdout.txt'], 'Two invalid inputs; zero damage/action messages')
    text = runs['special_exhaustion'].get('output', '')
    check('special_limit', 1, 'has no uses left!' in text and 'Special: 0/3' in text,
          ['special_exhaustion.stdout.txt'], 'Fourth special rejected after three uses')
    text = runs['win_replay'].get('output', '')
    check('natural_win', 6, '\nWIN\n' in text.replace('\r\n', '\n'), ['win_replay.stdout.txt'], 'Unmodified game reached WIN using normal actions')
    tail = text.split('WIN', 1)[-1]
    check('win_freeze', 7, 'Invalid input.' in tail.split('Choose your monster:', 1)[0]
          and 'for ' not in tail.split('Choose your monster:', 1)[0], ['win_replay.stdout.txt'], 'Attack at replay prompt rejected, not executed')
    check('fresh_replay', 8, text.count('Choose your monster:') == 2 and tail.count('Ignis (HP: 100/100, Special: 2/2)') >= 1,
          ['win_replay.stdout.txt'], 'Second battle displays full HP and special count')
    text = runs['lose'].get('output', '')
    check('natural_lose', 6, '\nLOSE\n' in text.replace('\r\n', '\n'), ['lose.stdout.txt'], 'Defense-only play eventually reaches LOSE')
    damage = re.findall(r'for (\d+) damage! \(Player was defending, damage halved!\)', text)
    check('player_defend', 2, bool(damage) and all(int(x) in (7, 9, 10, 15, 18, 20) for x in damage),
          ['lose.stdout.txt'], 'Actual damage messages with defense applied: ' + ','.join(damage[:12]))
    text = runs['eof'].get('output', '')
    check('eof', 10, runs['eof'].get('returncode') == 0 and 'EOF received. Exiting game.' in text,
          ['eof.stdout.txt'], 'EOF exits cleanly')
    observed = []
    for name, result in runs.items():
        output = result.get('output', '')
        # Aqua's attack is 15: any immediately-following attack after opponent
        # claims to defend must be reduced. Use only public messages, not state setters.
        if name == 'opponent_defense':
            for match in re.finditer(r'(Ignis|Terra) defends, halving incoming damage next turn\.(.*?)Aqua attacks \1 for (\d+) damage!', output, re.S):
                observed.append(int(match[3]))
    if observed:
        check('opponent_defense_has_real_effect', 3, all(x < 15 for x in observed),
              ['opponent_defense.stdout.txt'], f'Following Aqua attack damage: {observed}; normal attack=15')
    else:
        checks.append(dict(test_id='opponent_defense_has_real_effect', requirement_index=3,
                           status='NOT_RUN', actual='No opponent-defense then Aqua-attack pair observed'))
    final_text = runs['win_replay'].get('output', '').split('WIN', 1)[0]
    check('final_turn_hp_is_displayed', 4,
          bool(re.search(r'Opponent: .*HP: 0/', final_text)), ['win_replay.stdout.txt'],
          'Winning damage is printed, but the terminal-state opponent HP must also be shown')
    result = dict(status='FAIL' if any(c['status'] == 'FAIL' for c in checks) else 'PASS',
                  scope='Real native sandbox, black-box stdin/stdout only; no direct game-state manipulation',
                  source_unchanged=before == tree_hashes(out / 'game'), physical_keyboard='NOT_RUN', checks=checks)
    atomic_json(out / 'gameplay_checks.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main(sys.argv[1])
