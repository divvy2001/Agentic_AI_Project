"""Controlled diagnostic on a separate copy. Never modifies the recorded game."""
import difflib
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from evaluation.graphical_runtime import backend,clean_env,execution_status
from evaluation.records import tree_hashes
from evaluation.trials import atomic_json


def main(record):
    out=Path(record).resolve()/'godot'
    before=tree_hashes(out/'game')
    saved=out/'uid_diagnostic';saved.mkdir(exist_ok=False)
    stage=Path(tempfile.mkdtemp(prefix='lc-uid-control-'))
    shutil.copytree(out/'game',stage/'game')
    changes=[]
    for file in (stage/'game').glob('*.tscn'):
        text=file.read_text(encoding='utf-8')
        revised=re.sub(r'(?m)^(\[ext_resource[^\n]*)$',lambda m:re.sub(r' uid="[^"]+"','',m[0]),text)
        if revised!=text:
            file.write_text(revised,encoding='utf-8')
            changes.extend(difflib.unified_diff(text.splitlines(True),revised.splitlines(True),fromfile=file.name,tofile=file.name+' (diagnostic only)'))
    (saved/'diagnostic_only.diff').write_text(''.join(changes),encoding='utf-8')
    driver='''extends SceneTree
func _initialize(): call_deferred("protocol")
func walk(node: Node) -> Array:
    var nodes: Array = [node]
    for child in node.get_children(): nodes.append_array(walk(child))
    return nodes
func protocol():
    if change_scene_to_file("res://main.tscn")!=OK: quit(2);return
    for i in range(15): await process_frame
    var node_names: Array = []
    var hud_text: Array = []
    for node in walk(current_scene):
        node_names.append(str(node.get_path())+":"+node.get_class())
        if node is Label: hud_text.append(node.text)
    print("UID_CONTROL:"+JSON.stringify({"nodes":node_names,"hud":hud_text}))
    quit(0)
'''
    (stage/'observer.gd').write_text(driver,encoding='utf-8')
    sandbox=backend();binary=ROOT/'work/godot/Godot_v4.7.2-stable_win64.exe'
    imported=sandbox.launch(binary,['--headless','--editor','--path',str(stage/'game'),'--import','--quit'],stage,clean_env(),timeout=30,output_limit=262144)
    result=sandbox.launch(binary,['--headless','--path',str(stage/'game'),'--script',str(stage/'observer.gd'),
         '--fixed-fps','60','--quit-after','180'],stage,clean_env(),timeout=20,output_limit=262144)
    atomic_json(saved/'import.runtime.json',imported)
    atomic_json(saved/'runtime.json',result)
    atomic_json(saved/'summary.json',dict(scope='Controlled UID-only counterfactual, not a delivered fix or Repair result',
        original_game_unchanged=before==tree_hashes(out/'game'),runtime_status=execution_status('godot',result)))
    print(result.get('output',''))


if __name__=='__main__':main(sys.argv[1])
