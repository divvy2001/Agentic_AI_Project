"""One real fresh Planner/Asset/Coder run per documented case; source unchanged."""
import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "outputs/handoff/Bo's Project V4 - with coder"
sys.path.insert(0, str(ROOT))
from dotenv import dotenv_values
from evaluation.records import tree_hashes, cost_summary
from evaluation.trials import atomic_json
from evaluation.request_logging.http_usage import HTTPUsageRecorder
from evaluation.request_logging.accounting import SendGuard, read_attempts, reconcile
from evaluation.run import profile


def credentials():
    values = {}
    for location in (ROOT / "outputs/Bo's Project V4 - with coder/.env", SOURCE / '.env'):
        if location.exists():
            values.update({k: v for k, v in dotenv_values(location).items() if v})
    values.update({k: os.environ[k] for k in ('PLANNER_OPENROUTER_API_KEY', 'ASSET_OPENROUTER_API_KEY',
                                             'CODER_OPENROUTER_API_KEY') if os.environ.get(k)})
    return values


def setup():
    import httpx
    record = ROOT / 'outputs/test_records' / ('manual-three-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
    record.mkdir(parents=True, exist_ok=False)
    document = (SOURCE / 'docs/MANUAL_TESTS.md').read_text(encoding='utf-8')
    (record / 'MANUAL_TESTS.original.md').write_text(document, encoding='utf-8')
    prompts = []
    for section in document.split('## ')[1:4]:
        prompts.append(' '.join(line[2:].strip() for line in section.splitlines() if line.startswith('> ')))
    assert len(prompts) == 3 and all(prompts)
    keys = credentials()
    balance = {}
    with httpx.Client(timeout=30) as client:
        for stage in ('planner', 'asset', 'coder'):
            key = keys.get(stage.upper() + '_OPENROUTER_API_KEY')
            if not key:
                balance[stage] = {'status': 'MISSING_KEY'}
                continue
            try:
                response = client.get('https://openrouter.ai/api/v1/key', headers={'Authorization': 'Bearer ' + key})
                response.raise_for_status()
                data = response.json()['data']
                balance[stage] = {'status': 'OBSERVED', **{k: data.get(k) for k in ('limit', 'usage', 'limit_remaining')}}
            except Exception as exc:
                balance[stage] = {'status': 'UNAVAILABLE', 'error_type': type(exc).__name__}
    pricing = profile(live=True)
    session = dict(created_at=datetime.now(timezone.utc).isoformat(), source=str(SOURCE),
        source_hashes={n: tree_hashes(SOURCE / n) for n in ('coder_agent_adhoc', 'master_planner')},
        pricing=pricing, key_allowances_before=balance, cases={},
        policy='One Initial Build each; no silent retries/resume/Repair; preserve upstream failures; no production source edits',
        status='PREPARED')
    for case, prompt in zip(('terminal', 'pygame', 'godot'), prompts):
        out = record / case
        out.mkdir()
        (out / 'spec.txt').write_text(prompt + '\n', encoding='utf-8')
        project = Path(tempfile.mkdtemp(prefix='lc-manual-' + case + '-'))
        for folder in ('coder_agent_adhoc', 'master_planner'):
            shutil.copytree(SOURCE / folder, project / folder, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        shutil.copy2(SOURCE / 'config.py', project / 'config.py')
        for folder in ('plans', 'traces', 'game/assets'):
            (project / folder).mkdir(parents=True, exist_ok=True)
        (project / '.env').write_text('# Credentials are supplied in process memory only.\n')
        session['cases'][case] = str(project)
        atomic_json(out / 'state.json', dict(status='PREPARED', planner='NOT_RUN', assets='NOT_RUN', coder='NOT_RUN', gameplay='NOT_RUN'))
    atomic_json(record / 'session.json', session)
    print(json.dumps({'record': str(record), 'allowances': balance}, indent=2))


def worker(record, case):
    import httpx
    record = Path(record).resolve()
    session = json.loads((record / 'session.json').read_text(encoding='utf-8'))
    out = record / case
    state = json.loads((out / 'state.json').read_text(encoding='utf-8'))
    if state['status'] != 'PREPARED':
        raise ValueError('Refuse replay: case already started')
    project = Path(session['cases'][case])
    keys = credentials()
    for key, value in keys.items():
        if key.endswith('_OPENROUTER_API_KEY'):
            os.environ[key] = value
    os.environ['GODOT_BINARY'] = str(ROOT / 'work/godot/Godot_v4.7.2-stable_win64.exe')
    os.environ['ASSET_GENERATION_MODE'] = 'auto'
    # Current production defaults, recorded explicitly; external guard is additional.
    settings = dict(CODER_MAX_STEPS='40', CODER_MAX_SECONDS='1800', CODER_MAX_TOKENS='450000',
                    CODER_MODEL_MAX_OUTPUT_TOKENS='16384', CODER_MAX_COST_USD='0.40', CODER_MODEL='google/gemini-2.5-flash')
    os.environ.update(settings)
    os.chdir(project)
    sys.path.insert(0, str(project))
    all_secrets = [v for k, v in keys.items() if 'KEY' in k and v]
    state.update(status='RUNNING', settings=settings, pid=os.getpid(), source=str(SOURCE))
    atomic_json(out / 'state.json', state)
    try:
        import master_planner.planner.call_planner as planner
        from master_planner.asset.generator import image_generation as images
        original_planner = planner.ChatOpenAI
        original_request = images._request_json
        image_events = []
        with ExitStack() as stack:
            planner_recorders = []
            def planner_model(*args, **kwargs):
                model = original_planner(*args, **kwargs)
                observer = stack.enter_context(HTTPUsageRecorder(out / f'planner_http_{len(planner_recorders)+1}.jsonl',
                                                 case + '-planner', secrets=all_secrets))
                observer.attach(model.root_client._client)
                planner_recorders.append(observer)
                return model
            planner.ChatOpenAI = planner_model
            def image_request(url, key, method='GET', payload=None, timeout=60):
                event = dict(method=method, model=(payload or {}).get('model'), status='STARTED', cost_usd=None)
                if method == 'POST':
                    if len(image_events) >= 8:
                        raise RuntimeError('External test image POST safety limit reached')
                    image_events.append(event)
                    atomic_json(out / 'image_requests.json', image_events)
                try:
                    result = original_request(url, key, method, payload, timeout)
                    if method == 'POST':
                        event.update(status='RESPONSE', request_id=result.get('id'), usage=result.get('usage'))
                    return result
                except Exception as exc:
                    event.update(status='ERROR', error_type=type(exc).__name__)
                    raise
                finally:
                    if method == 'POST':
                        atomic_json(out / 'image_requests.json', image_events)
            images._request_json = image_request
            state['planner'] = 'RUNNING'
            atomic_json(out / 'state.json', state)
            from master_planner.run import run
            run((out / 'spec.txt').read_text(encoding='utf-8'), dry_run_planner=False, dry_run_assets=False)
        shutil.copytree(project / 'plans', out / 'planner_outputs')
        shutil.copytree(project / 'game/assets', out / 'asset_outputs')
        plan = json.loads((project / 'plans/coder_plan.json').read_text(encoding='utf-8'))
        state.update(planner=plan.get('status'), renderer=plan.get('profile', {}).get('renderer'),
                     dimensions=plan.get('profile', {}).get('dimensions'),
                     assets=plan['architecture']['assets']['strategy'], requirement_count=len(plan['requirements']))
        atomic_json(out / 'state.json', state)
        if state['renderer'] != case:
            state.update(status='BLOCKED', reason='Planner renderer does not match requested test; original request not satisfied')
            return
        if case == 'godot' and '3d' not in str(state['dimensions']).lower():
            state.update(status='BLOCKED', reason='Planner did not produce the requested genuine 3D plan')
            return
        from coder_agent_adhoc import agent_coder as agent
        original_factory = agent.create_model
        with HTTPUsageRecorder(out / 'coder_http.jsonl', case + '-build', secrets=all_secrets) as observer:
            guard = SendGuard(observer, dict(session['pricing'], budget_usd='0.40', max_output_tokens=16384, max_http_attempts=45))
            def model_factory():
                binding = original_factory()
                observer.attach(binding.bound.root_client._client)
                binding.bound.root_client._client.event_hooks['request'].insert(0, guard)
                return binding
            agent.create_model = model_factory
            state['coder'] = 'RUNNING'
            atomic_json(out / 'state.json', state)
            from coder_agent_adhoc.initial_build import run_initial_build
            result = run_initial_build(launch_game=False)
            atomic_json(out / 'build_result.json', result)
            state.update(status='BUILD_RETURNED', coder=result['status'], coder_reason=result.get('reason'),
                         usage=result.get('usage'), debug_statistics=result.get('debug_statistics'))
    except Exception as exc:
        message = str(exc)
        for key in all_secrets:
            message = message.replace(key, '[REDACTED]')
        state.update(status='ERROR', error_type=type(exc).__name__, reason=message[:2000])
    finally:
        for folder in ('plans', 'game', 'traces'):
            shutil.copytree(project / folder, out / folder, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.godot'))
        state['artifact_hashes'] = {name: tree_hashes(out / name) for name in ('plans', 'game', 'traces')}
        state['source_unchanged'] = all(tree_hashes(project / name) == session['source_hashes'][name]
                                         for name in ('coder_agent_adhoc', 'master_planner'))
        atomic_json(out / 'state.json', state)
        billing = {}
        with httpx.Client(timeout=30) as client:
            for stage in ('planner', 'coder'):
                rows = []
                for log in out.glob(stage + '_http*.jsonl'):
                    rows.extend(read_attempts(log))
                checked = reconcile(rows, client, keys.get(stage.upper() + '_OPENROUTER_API_KEY', ''))
                billing[stage] = cost_summary(checked)
                atomic_json(out / (stage + '_billing.json'), checked)
        billing['asset'] = {'posts': len(image_events) if 'image_events' in locals() else 0,
                            'cost_usd': None, 'note': 'Image billing unavailable unless supplied by response; never infer zero.'}
        atomic_json(out / 'billing_summary.json', billing)
        print(json.dumps(state, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('setup', 'worker'))
    parser.add_argument('--record')
    parser.add_argument('--case', choices=('terminal', 'pygame', 'godot'))
    args = parser.parse_args()
    if args.action == 'setup':
        setup()
    else:
        worker(args.record, args.case)
