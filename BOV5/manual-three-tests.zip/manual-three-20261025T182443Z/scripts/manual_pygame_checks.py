"""External public SDL input + Sprite rectangles + actual pixel/glyph observations."""
import json
from pathlib import Path
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from evaluation.graphical_runtime import backend, clean_env
from evaluation.records import tree_hashes
from evaluation.trials import atomic_json

CHILD = r'''
import hashlib,json,runpy,sys,weakref
from pathlib import Path
import numpy as np
import pygame
sys.path.insert(0,str(Path.cwd()))
from visual_match import locate_glyph
root=Path.cwd(); evidence=root/'evidence'; registry=[]; texts=[]; held=set(); frame=0; index=0; elapsed=0; rows=[]; loads=[]
actions=[dict(tag='initial',frames=3),dict(tag='wasd_right',hold=['d'],frames=15),
dict(tag='arrow_left',hold=['left'],frames=15),dict(tag='wasd_up',hold=['w'],frames=15),
dict(tag='arrow_down',hold=['down'],frames=15),dict(tag='boundary',hold=['a','w'],frames=300),
dict(tag='reset_boundary',press='r',frames=2),dict(tag='early_waypoint_1',target=[50,550]),
dict(tag='early_waypoint_2',target=[50,100]),dict(tag='pet_before_apples',target=[400,100]),
dict(tag='early_feed',press='e',frames=3),dict(tag='reset_before_collection',press='r',frames=2),
dict(tag='apple_1',target=[150,200]),dict(tag='apple_2',target=[650,250]),dict(tag='apple_3',target=[400,350]),
dict(tag='pet_after_apples',target=[400,100]),dict(tag='feed_win',press='e',frames=3),
dict(tag='freeze_win',hold=['d'],frames=25),dict(tag='reset_1',press='r',frames=2),
dict(tag='reset_2',press='r',frames=2),dict(tag='reset_3',press='r',frames=2),
dict(tag='escape',press='escape',frames=2),dict(tag='escape_unhandled',frames=3)]
codes={n:getattr(pygame,'K_'+n) for n in ['w','a','s','d','e','r','UP','DOWN','LEFT','RIGHT','ESCAPE']}
codes.update({n.lower():v for n,v in list(codes.items())})
sprite_init=pygame.sprite.Sprite.__init__; original_events=pygame.event.get; original_pressed=pygame.key.get_pressed
original_flip=pygame.display.flip; original_font=pygame.font.Font; original_load=pygame.image.load; original_clock=pygame.time.Clock
def register(self,*a,**kw):
    sprite_init(self,*a,**kw);registry.append(weakref.ref(self))
pygame.sprite.Sprite.__init__=register
def load(path,*a,**kw):
    loads.append(str(path));return original_load(path,*a,**kw)
pygame.image.load=load
class SeenFont(original_font):
    def render(self,text,*a,**kw):
        glyph=super().render(text,*a,**kw);texts.append((str(text),glyph,a[1] if len(a)>1 else kw.get('color')));return glyph
pygame.font.Font=SeenFont
class FixedClock:
    def __init__(self):self.real=original_clock()
    def tick(self,*a,**kw):return 16
    def get_time(self):return 16
    def get_fps(self):return 62.5
pygame.time.Clock=FixedClock
def sprites():return [ref() for ref in registry if ref() is not None and hasattr(ref(),'rect') and hasattr(ref(),'image')]
def player():return next((x for x in sprites() if type(x).__name__=='Player'),None)
class Keys:
    def __getitem__(self,key):return key in held
pygame.key.get_pressed=lambda:Keys()
def events(*a,**kw):
    global held
    action=actions[min(index,len(actions)-1)]; names=action.get('hold',[])
    obj=player()
    if 'target' in action and obj:
        dx=action['target'][0]-obj.rect.centerx;dy=action['target'][1]-obj.rect.centery
        names=[]
        if abs(dx)>4:names.append('d' if dx>0 else 'a')
        if abs(dy)>4:names.append('s' if dy>0 else 'w')
    desired={codes[n] for n in names}
    if action.get('press') and elapsed==0:desired.add(codes[action['press']])
    for key in held-desired:pygame.event.post(pygame.event.Event(pygame.KEYUP,key=key))
    for key in desired-held:pygame.event.post(pygame.event.Event(pygame.KEYDOWN,key=key,unicode=''))
    held=desired
    return original_events(*a,**kw)
pygame.event.get=events
class Done(BaseException):pass
def snapshot(tag):
    surface=pygame.display.get_surface();rgb=pygame.surfarray.array3d(surface);screen=rgb.transpose(1,0,2);seen=[]
    for obj in sprites():
        rect=obj.rect;image=obj.image;clip=rect.clip(surface.get_rect());ratio=None
        if clip.width and clip.height and image.get_size()==rect.size:
            expected=pygame.surfarray.array3d(image)[clip.x-rect.x:clip.right-rect.x,clip.y-rect.y:clip.bottom-rect.y]
            actual=rgb[clip.x:clip.right,clip.y:clip.bottom]
            alpha=pygame.surfarray.array_alpha(image)[clip.x-rect.x:clip.right-rect.x,clip.y-rect.y:clip.bottom-rect.y]
            mask=alpha>=250
            if mask.sum()>8:ratio=float(np.mean(np.all(expected[mask]==actual[mask],axis=1)))
        seen.append(dict(kind=type(obj).__name__,rect=list(rect),center=list(rect.center),pixel_match=ratio,
                         image_sha256=hashlib.sha256(pygame.image.tobytes(image,'RGBA')).hexdigest()))
    visible=[]
    for text,glyph,color in texts:
        color=tuple(pygame.Color(color))[:3]
        if locate_glyph(screen,pygame.surfarray.array3d(glyph).transpose(1,0,2),pygame.surfarray.array_alpha(glyph).transpose(1,0),color) is not None:visible.append(text)
    row=dict(tag=tag,frame=frame,visible_text=visible,sprites=seen,action=actions[index])
    rows.append(row);print('OBSERVATION:'+json.dumps(row),flush=True)
    if tag in ('initial','early_feed','feed_win','reset_3'):pygame.image.save(surface,str(evidence/(tag+'.png')))
def present():
    global frame,index,elapsed
    result=original_flip();frame+=1;elapsed+=1
    action=actions[index];obj=player();done=elapsed>=action.get('frames',400)
    if 'target' in action and obj:done=(abs(obj.rect.centerx-action['target'][0])<=4 and abs(obj.rect.centery-action['target'][1])<=4) or elapsed>=400
    if done:
        snapshot(action['tag']);index+=1;elapsed=0
        if index>=len(actions):raise Done()
    texts.clear()
    if frame>3000:raise Done()
    return result
pygame.display.flip=present
natural=False
try:runpy.run_path(str(root/'game/main.py'),run_name='__main__')
except SystemExit as exc:
    natural=exc.code in (None,0);print('NATURAL_EXIT:'+str(exc.code),flush=True)
except Done:print('HARNESS_STOP',flush=True)
finally:
    (evidence/'observations.json').write_text(json.dumps(dict(rows=rows,loaded_assets=loads,natural_exit=natural,last_action=actions[min(index,len(actions)-1)]['tag']),indent=2))
'''


def main(record, negative=False):
    out = Path(record).resolve() / 'pygame'
    before = tree_hashes(out / 'game')
    stage = Path(tempfile.mkdtemp(prefix='lc-pet-check-'))
    shutil.copytree(out / 'game', stage / 'game')
    (stage / 'evidence').mkdir()
    shutil.copy2(ROOT / 'evaluation/visual_match.py', stage / 'visual_match.py')
    child=CHILD
    if negative:
        child=child.replace('desired={codes[n] for n in names}', 'desired=set()')
        child=child.replace("if action.get('press') and elapsed==0:","if False and action.get('press') and elapsed==0:")
        child=child.replace('if frame>3000:', 'if frame>5000:')
    (stage / 'observer.py').write_text(child, encoding='utf-8')
    runtime = backend().launch(sys.executable, ['-I', '-B', str(stage / 'observer.py')], stage,
                               clean_env(), timeout=90, output_limit=262144, read_dirs=(sys.prefix,))
    saved = out / ('external_play_negative' if negative else 'external_play')
    shutil.copytree(stage / 'evidence', saved)
    atomic_json(saved / 'runtime.json', runtime)
    checks = []
    def check(name, value, actual):checks.append(dict(test_id=name,status='PASS' if value else 'FAIL',actual=actual))
    if (saved / 'observations.json').exists():
        observation=json.loads((saved/'observations.json').read_text());rows={r['tag']:r for r in observation['rows']}
        def pos(tag):
            return next((s['center'] for s in rows.get(tag,{}).get('sprites',[]) if s['kind']=='Player'),None)
        def apples(tag):
            return sum(s['kind']=='Apple' and (s.get('pixel_match') or 0)>.95 for s in rows.get(tag,{}).get('sprites',[]))
        def text(tag):return '|'.join(rows.get(tag,{}).get('visible_text',[]))
        check('runtime', runtime.get('returncode')==0 and not runtime.get('reason'),runtime.get('reason'))
        check('wasd_movement',pos('initial') is not None and pos('wasd_right')[0]>pos('initial')[0],pos('wasd_right'))
        check('arrow_movement',pos('arrow_left') is not None and pos('arrow_left')[0]<pos('wasd_right')[0],pos('arrow_left'))
        check('vertical_wasd_arrows',pos('wasd_up')[1]<pos('arrow_left')[1] and pos('arrow_down')[1]>pos('wasd_up')[1],pos('arrow_down'))
        check('bounds',pos('boundary')==[16,16],pos('boundary'))
        check('early_feed_rejected','WIN!' not in text('early_feed') and 'Apples: 0' in text('early_feed'),text('early_feed'))
        check('collect_all_three_once','Apples: 3' in text('apple_3') and apples('apple_3')==0,text('apple_3'))
        check('feed_requires_proximity','WIN!' not in text('apple_3') and 'WIN!' not in text('pet_after_apples'),text('pet_after_apples'))
        check('actual_visible_win','WIN!' in text('feed_win'),text('feed_win'))
        check('freeze_after_win',pos('feed_win') is not None and pos('feed_win')==pos('freeze_win') and 'WIN!' in text('feed_win'),pos('freeze_win'))
        for tag in ('reset_1','reset_2','reset_3'):
            check(tag,pos(tag)==[400,550] and 'Apples: 0' in text(tag) and 'WIN!' not in text(tag) and apples(tag)==3 and len(rows[tag]['sprites'])==5,
                  dict(position=pos(tag),visible_apples=apples(tag),sprites=len(rows.get(tag,{}).get('sprites',[]))))
        check('escape_quits',observation['natural_exit'] and observation['last_action']=='escape',observation['last_action'])
        check('required_assets_loaded',all(any(name in path for path in observation['loaded_assets']) for name in
              ('player_character.png','pet_normal.png','pet_happy.png','apple.png','garden_background.png')),observation['loaded_assets'])
        # Compare actual public Sprite image pixels; do not read the game's win flag.
        normal=next((s.get('pixel_match') for s in rows.get('initial',{}).get('sprites',[]) if s['kind']=='Pet'),None)
        happy=next((s.get('pixel_match') for s in rows.get('feed_win',{}).get('sprites',[]) if s['kind']=='Pet'),None)
        check('pet_image_presented',normal is not None and happy is not None and normal>.95 and happy>.95,[normal,happy])
        initial_pet=next((s.get('image_sha256') for s in rows.get('initial',{}).get('sprites',[]) if s['kind']=='Pet'),None)
        winning_pet=next((s.get('image_sha256') for s in rows.get('feed_win',{}).get('sprites',[]) if s['kind']=='Pet'),None)
        check('pet_visual_reaction_changes_image',bool(initial_pet) and initial_pet!=winning_pet,[initial_pet,winning_pet])
    result=dict(status='FAIL' if not checks or any(c['status']=='FAIL' for c in checks) else 'PASS',checks=checks,
                scope='External SDL events and controlled public held-key/clock API; real surface pixels and visible glyphs; physical keyboard NOT_RUN',
                source_unchanged=before==tree_hashes(out/'game'),runtime_evidence=str(saved.relative_to(out)/'runtime.json'),
                input_drop_negative_control=negative)
    atomic_json(out/('gameplay_checks_negative.json' if negative else 'gameplay_checks.json'),result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main(sys.argv[1], '--negative' in sys.argv[2:])
