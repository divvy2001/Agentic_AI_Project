"""Seal complete plans/assets/games and evidence; report failures without repairing."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from evaluation.records import tree_hashes
from evaluation.trials import atomic_json
from dotenv import dotenv_values


def read(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main(record):
    record=Path(record).resolve()
    session=read(record/'session.json')
    source=Path(session['source'])
    summary=dict(date='2026-10-26 Asia/Shanghai',completed_at=datetime.now(timezone.utc).isoformat(),
        scope='One real fresh Planner + Asset + Coder Initial Build for each exact documented prompt; external functional tests and visual review',
        independent_repair_invocations=0, resumed_builds=0, production_source_modified=False,
        cases={},physical_keyboard='NOT_RUN',formal_success_rate='NOT_ESTABLISHED',
        planner_coder_verified_cost_usd=0.0,asset_response_reported_cost_usd=0.0)
    for case in ('terminal','pygame','godot'):
        out=record/case
        state=read(out/'state.json');build=read(out/'build_result.json');checks=read(out/'gameplay_checks.json')
        if case=='godot':
            checks['checks'][-1]['actual']='Not executed: token-exhausted Build and startup script error; only independent startup diagnosis was performed.'
            atomic_json(out/'gameplay_checks.json',checks)
        bills=read(out/'billing_summary.json')
        images=read(out/'image_requests.json') if (out/'image_requests.json').exists() else []
        costs=[x.get('usage',{}).get('cost') if isinstance(x.get('usage'),dict) else None for x in images]
        image_cost=sum(costs) if all(isinstance(x,(int,float)) and not isinstance(x,bool) for x in costs) else None
        bills['asset']=dict(posts=len(images),response_reported_cost_usd=image_cost,
                           independently_billing_verified=False if images else None,
                           note='Provider response usage.cost; no generation ID available for independent audit.' if images else 'No image API requests; no image-generation charge.')
        atomic_json(out/'billing_summary.json',bills)
        asset_stats=[]
        from PIL import Image
        for path in sorted((out/'game/assets').glob('*.png')):
            with Image.open(path) as image:
                alpha=image.convert('RGBA').getchannel('A')
                extrema=alpha.getextrema()
                asset_stats.append(dict(path=path.relative_to(out).as_posix(),size=list(image.size),
                     alpha_extrema=list(extrema),fully_opaque=extrema==(255,255),sha256=sha(path)))
        atomic_json(out/'asset_pixel_audit.json',asset_stats)
        traces=[json.loads(line) for line in (out/'traces/coder_attempts.jsonl').read_text(encoding='utf-8').splitlines()]
        failures=[e for e in traces if e.get('event')=='local_failure']
        patch_misses=[e for e in failures if 'patch_context_not_unique_or_missing' in json.dumps(e)]
        stats=dict(local_failure_events=len(failures),patch_context_misses=len(patch_misses),
                   phase_checks=sum(e.get('event')=='integration_phase' for e in traces),
                   provider_retries=sum(e.get('event')=='provider_retry' for e in traces))
        atomic_json(out/'loop_analysis.json',stats)
        verdict='FAIL' if case=='terminal' else 'FUNCTIONAL_PASS_VISUAL_ISSUES' if case=='pygame' else 'BUILD_FAILED'
        model_cost=sum(bills[s]['known_cost_lower_bound_usd'] for s in ('planner','coder'))
        result=dict(assessment=verdict,planner_status=state['planner'],renderer=state['renderer'],
            asset_strategy=state['assets'],asset_count=len(asset_stats),build_status=build['status'],
            build_reason=build.get('reason'),steps=build['steps'],usage=build.get('usage'),
            functional_status=checks['status'],check_counts={s:sum(x['status']==s for x in checks['checks']) for s in ('PASS','FAIL','NOT_RUN')},
            code_unchanged_during_external_tests=checks['source_unchanged'],loop=stats,
            planner_coder_verified_cost_usd=model_cost,asset_response_reported_cost_usd=image_cost,
            total_reported_cost_usd=model_cost+image_cost if image_cost is not None else None)
        summary['cases'][case]=result
        summary['planner_coder_verified_cost_usd']+=model_cost
        if image_cost is not None:summary['asset_response_reported_cost_usd']+=image_cost
        state.update(gameplay=checks['status'],assessment=verdict,external_check_counts=result['check_counts'])
        atomic_json(out/'state.json',state)
        if case in ('terminal','pygame'):
            play='From this case directory, activate the configured Python environment and run:\n\n```powershell\npython -m game.main\n```\n\n'
        else:
            play='This original output FAILED Initial Build. It is preserved for diagnosis, not a passed reference game.\n\nOpen game/project.godot in Godot 4 to reproduce the startup error.\n\n'
        play+='Read spec.txt, plans/coder_plan.json, plans/play_manual.json (if present), build_result.json and gameplay_checks.json.\nNo API key is needed to play existing Python game files. Never treat this as permission to launch a new paid Build.\n'
        (out/'PLAY.md').write_text('# Saved game\n\n'+play,encoding='utf-8')
    summary['total_reported_cost_usd']=summary['planner_coder_verified_cost_usd']+summary['asset_response_reported_cost_usd']
    summary['all_costs_independently_verified']=False
    summary['source_still_unchanged']=all(tree_hashes(source/name)==session['source_hashes'][name]
                                         for name in ('coder_agent_adhoc','master_planner'))
    summary['status']='COMPLETED_WITH_FAILURES'
    summary['pygame_negative_control']=read(record/'pygame/gameplay_checks_negative.json')['status']
    summary['godot_uid_control']=read(record/'godot/uid_diagnostic/summary.json')
    atomic_json(record/'summary.json',summary)
    session.update(status='COMPLETED_WITH_FAILURES',summary='summary.json')
    atomic_json(record/'session.json',session)
    doc='''# Three documented real pipeline trials

Date: 2026-10-26 (Asia/Shanghai). Source: the user's `outputs/handoff/Bo's Project V4 - with coder`.
The three prompts were extracted verbatim (whitespace joined) from MANUAL_TESTS.md.
Each used a fresh isolated workspace, real Planner/Asset calls and one Initial Build.
No code changes to Coder/Planner/Asset, no Build resume and no external Repair were used.
Local self-debugging inside each Build remains included in that Build's cost and result.

## Results

| Case | Planner | Asset | Initial Build | External functional result |
|---|---|---|---|---|
| Terminal Monster Trio | Success, 11 requirements | none, no image requests | ready_for_testing, 30 calls | 12 PASS, 2 FAIL |
| Pygame Pixel Pet Garden | Success, 13 requirements | 5 real AI-generated PNGs, manifest passed | ready_for_testing, 2 calls | 17 PASS; visual issues remain |
| Godot 3D Energy Extraction | Success, 15 requirements, genuine 3D | procedural, no image requests | token_budget_exhausted, 32 calls | Import passed; actual startup script error; gameplay NOT_RUN |

These are three development examples, not a statistically meaningful success rate.
Only two reached internal readiness, and readiness is separate from feature correctness.
The Godot final receipt resets smoke fields to not_run on budget stop; earlier phase
checks and the independent native startup diagnosis preserve actual failures separately.

## Terminal: functional failures found

Nine real sandboxed stdin/stdout sessions cover all three monster choices, invalid
input, limited special moves, natural WIN/LOSE, replay, freeze, quitting and EOF.
No private battle functions or state setters were used.

1. Opponent defense is advertised but not applied: in `opponent_defense.stdout.txt`,
   a defending opponent subsequently receives Aqua's full 15 damage. The opponent
   code prints a defense claim but does not carry the reduction into player_turn.
   This is a semantic action-consistency defect, even though the narrow Planner
   check only requires a legal opponent action to be displayed.
2. The final winning turn has no refreshed HP/special display: damage/WIN is printed
   and the loop breaks before another stats display. This violates the request's
   after-every-turn visibility requirement. See win_replay.stdout.txt.

The 30-call Build used 231210 input and 13615 output tokens. Repeated patch context
misses, source rereads and local debugging consumed much more work than this small
game's feature count suggests; loop_analysis.json gives the exact event counts.
There was no external Repair; all changes belong to the initial invocation.

## Pygame: functional success, visual limitations

Five actual image POST responses succeeded: player_character, pet_normal, pet_happy,
apple and garden_background. All are preserved in both asset_outputs/ and game/assets/.
Their original manifest and provider usage are preserved; no procedural image fallback.
The generated game loaded all five and actual surface pixels/glyphs were observed.

Seventeen checks passed: WASD/arrow motion on both axes, bounds, early-feed rejection,
three single-use collections, feed near pet, visible WIN, freeze, three fresh resets,
Escape, asset loading/presentation and pet-image change. Input is external SDL events
plus controlled public held-key and clock APIs. It does not establish physical OS
keyboard delivery or real-time FPS. The normal game source was not edited.

The separate input-drop negative control is expected to FAIL: movement/collection/
WIN/quit checks reject a running but undriven game. Its FAIL is grader calibration,
not an additional failure of the positive generated game.

Actual screenshots were visually reviewed. Foreground graphics have obvious white
background boxes. The normal pet looks like a fox, while its happy image looks like
a different purple creature. The reaction occurs, but identity/compositing consistency
is poor. Functional 17/17 does not certify finished visual quality. See the initial,
early_feed, feed_win and reset_3 PNGs, plus asset_pixel_audit.json.

## Godot: confirmed resource-identity startup failure

The Build used 418517 input and 32800 output tokens (451317 total), exhausting the
450000 cumulative-token budget after 32 calls. It did not deliver a ready game.

Independent native import succeeds, but actual startup raises:
`Invalid assignment ... position ... Vector3 ... CanvasLayer (hud.gd)` in main.gd:86.
The supposed Orb instance is a HUD. The original live scene contains /Orbs/HUD,
no actual orb Area3D instances, and duplicate HUD labels. A real screenshot is saved.

The main scene's external Orb and HUD references share one UID; the Orb reference's
UID also disagrees with the actual orb.tscn header. In a SEPARATE diagnostic copy,
removing external-resource UID attributes alone eliminates this startup error and
produces three real Orb Area3D nodes. The original game remains unchanged. This
counterfactual establishes a resource-identity cause; it is not an official fix,
Repair invocation, successful Build or full gameplay acceptance.

The initialization error prevents later object setup. Full movement, collection,
win/loss, resets, Escape and cross-frame-rate behavior are NOT_RUN on the original
failed output. Static review also finds `_process()` returning on game_over before
processing R/Escape; terminal-state reset/quit is therefore a separate likely defect,
not a behavior verified in this blocked run.

The upstream procedural manifest says validation=false with errors=[] because its
validator requires a non-empty asset list. The scenario intentionally has no image
assets. Preserve this inconsistency as an upstream status issue; it is not proof of
a failed image request, and no image request was made for this case.

An initial observer setup attempt failed while reading UTF-8 JSON as Windows GBK;
it launched no game. Its INFRA_ERROR is retained in external_play/. After fixing
only observer decoding, external_play_v2/ records the real game startup error.
Do not attribute the observer setup error to the generated game.

## What to improve next (analysis only; no production edits)

1. Validate external UID/path consistency and instantiated scene roles, not only
   resource existence/TSCN syntax. Prefer generated references without fabricated UIDs.
2. Tie action promises and terminal states to behavior checks: real defense effects,
   final HP display, R/Escape before outcome freeze branches, and fresh reset state.
3. Reduce repeated patch misses/read cycles; retain exact current excerpts and use
   a different edit strategy after repeated misses. Extra budget alone does not fix
   a wrong scene identity or inconsistent mechanics.
4. Require consistent normal/happy asset identity and compositing/transparency review;
   file existence and correct PNG dimensions do not establish usable visual assets.

## Cost, limits and reproducibility

Current production defaults were recorded explicitly: Flash model, 40 steps,
1800 seconds, 450000 cumulative tokens, 16384 output-token cap. The external test
adds a USD 0.40 Coder reservation guard per case and at most eight image POSTs.
No case was retried to select a better sample. All actual calls/errors are retained.

Planner and Coder charges were independently reconciled using generation metadata.
Image costs come from successful response usage.cost and lack generation IDs for
independent lookup. summary.json separates the confidence of these amounts. Zero
image calls in Terminal/Godot mean zero image-generation charge, not missing cost.

Physical keyboard, complete human play and Godot cross-FPS verification are NOT_RUN.
This test does not compare Baseline 01, establish a general first-build success rate,
or authorize a new release. The handoff source remains byte-identical.

## Saved files

Every case preserves spec.txt, complete plans/ (raw Planner Plan, Coder view, manifest
and manual where produced), asset_outputs/, full original game/, traces/, native
logs, actual usage/billing and functional observations. Terminal includes each input
and stdout transcript. Pygame includes positive/negative observations and screenshots.
Godot includes original startup screenshot/error and the separate UID control diff.

Use each case's PLAY.md to launch an existing game without model calls. Godot is a
failed debug artifact. `scripts/` preserves external test orchestration; it relies
on the developer workspace's evaluation/native backend, not a standalone test SDK.
MANIFEST.sha256.json seals the saved evidence. No API keys or .env files are included.
'''
    costs='\n## Actual reported cost\n\n| Case | Planner + Coder (independently verified USD) | Images (response-reported USD) | Total reported USD |\n|---|---:|---:|---:|\n'
    for case,result in summary['cases'].items():
        costs+=f"| {case} | {result['planner_coder_verified_cost_usd']:.8f} | {result['asset_response_reported_cost_usd']:.8f} | {result['total_reported_cost_usd']:.8f} |\n"
    costs+=f"\nTotal reported: **USD {summary['total_reported_cost_usd']:.8f}**. Image amounts are not independently billing-audited.\n"
    (record/'REPORT.md').write_text(doc+costs,encoding='utf-8')
    scripts=record/'scripts';scripts.mkdir(exist_ok=True)
    for name in ('manual_three_trials.py','manual_terminal_checks.py','manual_pygame_checks.py',
                 'manual_godot_checks.py','manual_uid_diagnostic.py','finalize_manual_three.py'):
        shutil.copy2(ROOT/'work'/name,scripts/name)
    secrets=[]
    for file in (ROOT/"outputs/Bo's Project V4 - with coder/.env",source/'.env'):
        if file.exists():secrets.extend(v for k,v in dotenv_values(file).items() if v and 'KEY' in k and len(v)>12)
    for path in record.rglob('*'):
        if not path.is_file():continue
        data=path.read_bytes()
        if path.name=='.env' or any(v.encode() in data for v in secrets) or re.search(rb'sk-or-v1-[A-Za-z0-9]{20,}',data):
            raise ValueError('Credential finding: '+path.relative_to(record).as_posix())
    manifest={p.relative_to(record).as_posix():sha(p) for p in sorted(record.rglob('*')) if p.is_file() and p.name!='MANIFEST.sha256.json'}
    atomic_json(record/'MANIFEST.sha256.json',manifest)
    archive=record.with_suffix('.zip')
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as zipped:
        for path in sorted(record.rglob('*')):
            zipped.write(path,record.name+'/'+path.relative_to(record).as_posix())
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        assert all(hashlib.sha256(zipped.read(record.name+'/'+name)).hexdigest()==digest for name,digest in manifest.items())
    archive.with_suffix('.zip.sha256').write_text(sha(archive)+'  '+archive.name+'\n',encoding='ascii')
    print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,cost=summary['total_reported_cost_usd'],
                         cases={k:{f:v[f] for f in ('assessment','check_counts','steps')} for k,v in summary['cases'].items()},
                         source_unchanged=summary['source_still_unchanged']),indent=2))


if __name__=='__main__':main(sys.argv[1])
