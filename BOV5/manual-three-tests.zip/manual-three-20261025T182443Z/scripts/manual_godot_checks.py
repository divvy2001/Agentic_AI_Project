"""External Godot 3D protocol: real InputEvents, public nodes/HUD, actual screenshots."""
import json
from pathlib import Path
import shutil
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from evaluation.graphical_runtime import backend,clean_env,execution_status
from evaluation.records import tree_hashes
from evaluation.trials import atomic_json

DRIVER='''extends SceneTree
var rows: Array = []
var pressed_codes: Array = []
func _initialize():
    call_deferred("protocol")
func walk(node: Node) -> Array:
    if node == null: return []
    var result: Array = [node]
    for child in node.get_children(): result.append_array(walk(child))
    return result
func actor() -> CharacterBody3D:
    if current_scene == null: return null
    return current_scene.get_node_or_null("Player") as CharacterBody3D
func labels() -> Array:
    var result: Array = []
    for node in walk(current_scene):
        if node is Label and node.is_visible_in_tree(): result.append(node.text)
    return result
func outcome() -> bool:
    for text in labels():
        if "WIN" in text or "LOSE" in text: return true
    return false
func ticks(count: int):
    for i in range(count):
        await physics_frame
        await process_frame
func key(code: int, down: bool):
    var event := InputEventKey.new()
    event.keycode = code
    event.physical_keycode = code
    event.pressed = down
    Input.parse_input_event(event)
    Input.flush_buffered_events()
func keys(desired: Array):
    for code in pressed_codes:
        if not code in desired: key(code,false)
    for code in desired:
        if not code in pressed_codes: key(code,true)
    pressed_codes = desired.duplicate()
func pulse(code: int):
    keys([code])
    await ticks(2)
    keys([])
    await ticks(5)
func snap(tag: String, image: bool = false):
    var p := actor()
    var orb_positions: Array = []
    var names: Array = []
    var mesh_count: int = 0
    var camera: Camera3D = root.get_camera_3d()
    var visible_player: bool = false
    if camera and p:
        visible_player = not camera.is_position_behind(p.global_position) and root.get_visible_rect().has_point(camera.unproject_position(p.global_position))
    for node in walk(current_scene):
        names.append(str(node.get_path()))
        if node is MeshInstance3D and node.mesh and node.is_visible_in_tree(): mesh_count += 1
        if node is Area3D and node.get_script() and str(node.get_script().resource_path).ends_with("orb.gd"):
            orb_positions.append([node.global_position.x,node.global_position.y,node.global_position.z])
    var row: Dictionary = {"tag":tag,"physics_frame":Engine.get_physics_frames(),"hud":labels(),"orb_positions":orb_positions,"node_names":names,"visible_meshes":mesh_count,"camera_sees_player":visible_player}
    if p: row["player"]=[p.global_position.x,p.global_position.y,p.global_position.z]
    rows.append(row)
    print("OBSERVATION:"+JSON.stringify(row))
    var file := FileAccess.open("EVIDENCE_PATH/observations.json",FileAccess.WRITE)
    file.store_string(JSON.stringify(rows,"  "))
    file.close()
    if image:
        await RenderingServer.frame_post_draw
        var picture: Image = root.get_texture().get_image()
        picture.save_png("EVIDENCE_PATH/"+tag+".png")
func move_to(target: Vector2):
    for i in range(400):
        var p := actor()
        if p == null or outcome(): break
        var delta_x: float = target.x-p.global_position.x
        var delta_z: float = target.y-p.global_position.z
        if abs(delta_x)<0.3 and abs(delta_z)<0.3: break
        var desired: Array = []
        if abs(delta_x)>=0.3: desired.append(KEY_D if delta_x>0 else KEY_A)
        if abs(delta_z)>=0.3: desired.append(KEY_S if delta_z>0 else KEY_W)
        keys(desired)
        await ticks(1)
    keys([])
    await ticks(3)
func protocol():
    if change_scene_to_file("res://main.tscn") != OK:
        print("SCENE_LOAD_FAILED")
        quit(2)
        return
    await ticks(8)
    await snap("initial",true)
    if actor()==null:
        print("PLAYER_NODE_UNAVAILABLE")
        quit(2)
        return
    keys([KEY_D]);await ticks(30);keys([]);await ticks(2);await snap("wasd_right")
    keys([KEY_LEFT]);await ticks(30);keys([]);await ticks(2);await snap("arrow_left")
    keys([KEY_W]);await ticks(30);keys([]);await ticks(2);await snap("wasd_up")
    keys([KEY_DOWN]);await ticks(30);keys([]);await ticks(2);await snap("arrow_down")
    keys([KEY_D]);await ticks(180);keys([]);await ticks(2);await snap("boundary")
    await pulse(KEY_R);await snap("reset_boundary")
    await move_to(Vector2(-15,0));await move_to(Vector2(-15,15));await snap("locked_exit")
    await pulse(KEY_R);await snap("reset_before_collection")
    await move_to(Vector2(-10,0));await move_to(Vector2(-10,-10));await snap("orb_1")
    await move_to(Vector2(10,-10));await snap("orb_2")
    await move_to(Vector2(-15,-10));await move_to(Vector2(-15,10));await move_to(Vector2(0,10));await snap("orb_3")
    await move_to(Vector2(-15,10));await move_to(Vector2(-15,15));await snap("exit_after_orbs",true)
    keys([KEY_D]);await ticks(30);keys([]);await ticks(2);await snap("freeze_win")
    await pulse(KEY_R);await snap("reset_after_win")
    await move_to(Vector2(5,0));await move_to(Vector2(5,5));await snap("hazard",true)
    keys([KEY_LEFT]);await ticks(30);keys([]);await ticks(2);await snap("freeze_lose")
    await pulse(KEY_R);await snap("reset_1")
    await pulse(KEY_R);await snap("reset_2")
    await pulse(KEY_R);await snap("reset_3",true)
    print("ESCAPE_SENT")
    keys([KEY_ESCAPE])
    await ticks(8)
    print("ESCAPE_NOT_HANDLED")
    quit(2)
'''


def main(record):
    out=Path(record).resolve()/'godot'
    saved=out/'external_play'
    if saved.exists(): saved=out/'external_play_v2'
    saved.mkdir(exist_ok=False)
    before=tree_hashes(out/'game')
    stage=Path(tempfile.mkdtemp(prefix='lc-energy-check-'))
    shutil.copytree(out/'game',stage/'game',ignore=shutil.ignore_patterns('.godot','__pycache__'))
    (stage/'evidence').mkdir()
    build=json.loads((out/'build_result.json').read_text(encoding='utf-8'))
    driver=DRIVER
    if build['status']!='ready_for_testing':
        # Incomplete delivery: diagnose actual startup, never run stale routes or
        # turn missing functionality into a collection of artificial test failures.
        driver=DRIVER[:DRIVER.index('func protocol():')]+'''func protocol():
    if change_scene_to_file("res://main.tscn") != OK:
        print("SCENE_LOAD_FAILED")
        quit(2)
        return
    await ticks(10)
    await snap("initial",true)
    print("STARTUP_DIAGNOSTIC_ONLY_INCOMPLETE_BUILD")
    quit(0)
'''
    (stage/'observer.gd').write_text(driver.replace('EVIDENCE_PATH',(stage/'evidence').as_posix()),encoding='utf-8')
    sandbox=backend();binary=ROOT/'work/godot/Godot_v4.7.2-stable_win64.exe'
    imported=sandbox.launch(binary,['--headless','--editor','--path',str(stage/'game'),'--import','--quit'],stage,clean_env(),timeout=30,output_limit=262144)
    atomic_json(saved/'import.runtime.json',imported)
    runtime=sandbox.launch(binary,['--path',str(stage/'game'),'--script',str(stage/'observer.gd'),
        '--rendering-method','gl_compatibility','--fixed-fps','60','--quit-after','8000',
        '--resolution','800x600','--position','40,40'],stage,clean_env(),timeout=90,output_limit=262144)
    atomic_json(saved/'runtime.json',runtime)
    shutil.copytree(stage/'evidence',saved,dirs_exist_ok=True)
    checks=[]
    def check(name,value,actual):checks.append(dict(test_id=name,status='PASS' if value else 'FAIL',actual=actual))
    check('real_scene_import',execution_status('godot',imported)=='PASS',imported.get('reason'))
    check('no_runtime_script_errors',execution_status('godot',runtime)=='PASS',runtime.get('reason'))
    rows=json.loads((saved/'observations.json').read_text(encoding='utf-8')) if (saved/'observations.json').exists() else []
    by_tag={r['tag']:r for r in rows}
    def pos(tag):return by_tag.get(tag,{}).get('player')
    def hud(tag):return '|'.join(by_tag.get(tag,{}).get('hud',[]))
    if rows and all(pos(tag) is not None for tag in ('initial','wasd_right','arrow_left','wasd_up','arrow_down','boundary')):
        check('camera_and_meshes',by_tag['initial']['camera_sees_player'] and by_tag['initial']['visible_meshes']>=5,by_tag['initial']['visible_meshes'])
        check('wasd_x',pos('wasd_right')[0]>pos('initial')[0]+1,pos('wasd_right'))
        check('arrow_x',pos('arrow_left')[0]<pos('wasd_right')[0]-1,pos('arrow_left'))
        check('wasd_z',pos('wasd_up')[2]<pos('arrow_left')[2]-1,pos('wasd_up'))
        check('arrow_z',pos('arrow_down')[2]>pos('wasd_up')[2]+1,pos('arrow_down'))
        check('solid_boundary',pos('boundary')[0]<20,pos('boundary'))
        check('locked_exit','WIN' not in hud('locked_exit') and 'LOSE' not in hud('locked_exit') and len(by_tag.get('locked_exit',{}).get('orb_positions',[]))==3,hud('locked_exit'))
        for n in (1,2,3):
            check('orb_'+str(n),len(by_tag.get('orb_'+str(n),{}).get('orb_positions',[]))==3-n,hud('orb_'+str(n)))
        check('natural_win','WIN' in hud('exit_after_orbs'),hud('exit_after_orbs'))
        check('freeze_win',pos('freeze_win')==pos('exit_after_orbs'),pos('freeze_win'))
        check('natural_lose','LOSE' in hud('hazard'),hud('hazard'))
        check('freeze_lose',pos('freeze_lose')==pos('hazard'),pos('freeze_lose'))
        initial=by_tag['initial']
        for tag in ('reset_after_win','reset_1','reset_2','reset_3'):
            row=by_tag.get(tag,{})
            check(tag,pos(tag)==pos('initial') and len(row.get('orb_positions',[]))==3 and
                len(row.get('node_names',[]))==len(initial['node_names']) and 'WIN' not in hud(tag) and 'LOSE' not in hud(tag),hud(tag))
        check('escape_quits','ESCAPE_SENT' in runtime.get('output','') and 'ESCAPE_NOT_HANDLED' not in runtime.get('output','') and runtime.get('returncode')==0,runtime.get('returncode'))
    else:
        checks.append(dict(test_id='functional_protocol',status='NOT_RUN',actual=(
            'Not executed: incomplete Build; independent startup diagnostic only.'
            if build['status']!='ready_for_testing' else 'Required scene/player observations unavailable')))
    result=dict(status='FAIL' if any(x['status']=='FAIL' for x in checks) else 'INCOMPLETE' if any(x['status']=='NOT_RUN' for x in checks) else 'PASS',
                checks=checks,source_unchanged=before==tree_hashes(out/'game'),
                runtime_evidence=str(saved.relative_to(out)/'runtime.json'),
                scope='Native Godot InputEvents and public node/visible HUD observations; physical keyboard NOT_RUN',
                frame_rate_comparison='NOT_RUN', incomplete_build_diagnostic_only=build['status']!='ready_for_testing')
    atomic_json(out/'gameplay_checks.json',result)
    print(json.dumps(result,indent=2))


if __name__=='__main__':main(sys.argv[1])
