# Three documented real pipeline trials

Date: 2026-10-26 (Asia/Shanghai). Source: the user's `outputs/handoff/Bo's Project V4 - with coder`.
The three prompts were extracted verbatim (whitespace joined) from MANUAL_TESTS.md.
Each used a fresh isolated workspace, real Planner/Asset calls and one Initial Build.
No code changes to Coder/Planner/Asset, no Build resume and no external Repair were used.
Local self-debugging inside each Build remains included in that Build's cost and result.

## Results

| Case | Planner | Asset | Initial Build | External functional result |
|---|---|---|---|---|
| Terminal Monster Trio | Success, 11 requirements | none, no image requests | ready_for_testing, 30 calls | 12 PASS, 2 FAIL |
| Pygame Pixel Pet Garden | Success, 13 requirements | 5 real AI-generated PNGs, manifest passed | ready_for_testing, 2 calls | 17 PASS; visual issues remain |
| Godot 3D Energy Extraction | Success, 15 requirements, genuine 3D | procedural, no image requests | token_budget_exhausted, 32 calls | Import passed; actual startup script error; gameplay NOT_RUN |

These are three development examples, not a statistically meaningful success rate.
Only two reached internal readiness, and readiness is separate from feature correctness.
The Godot final receipt resets smoke fields to not_run on budget stop; earlier phase
checks and the independent native startup diagnosis preserve actual failures separately.

## Terminal: functional failures found

Nine real sandboxed stdin/stdout sessions cover all three monster choices, invalid
input, limited special moves, natural WIN/LOSE, replay, freeze, quitting and EOF.
No private battle functions or state setters were used.

1. Opponent defense is advertised but not applied: in `opponent_defense.stdout.txt`,
   a defending opponent subsequently receives Aqua's full 15 damage. The opponent
   code prints a defense claim but does not carry the reduction into player_turn.
   This is a semantic action-consistency defect, even though the narrow Planner
   check only requires a legal opponent action to be displayed.
2. The final winning turn has no refreshed HP/special display: damage/WIN is printed
   and the loop breaks before another stats display. This violates the request's
   after-every-turn visibility requirement. See win_replay.stdout.txt.

The 30-call Build used 231210 input and 13615 output tokens. Repeated patch context
misses, source rereads and local debugging consumed much more work than this small
game's feature count suggests; loop_analysis.json gives the exact event counts.
There was no external Repair; all changes belong to the initial invocation.

## Pygame: functional success, visual limitations

Five actual image POST responses succeeded: player_character, pet_normal, pet_happy,
apple and garden_background. All are preserved in both asset_outputs/ and game/assets/.
Their original manifest and provider usage are preserved; no procedural image fallback.
The generated game loaded all five and actual surface pixels/glyphs were observed.

Seventeen checks passed: WASD/arrow motion on both axes, bounds, early-feed rejection,
three single-use collections, feed near pet, visible WIN, freeze, three fresh resets,
Escape, asset loading/presentation and pet-image change. Input is external SDL events
plus controlled public held-key and clock APIs. It does not establish physical OS
keyboard delivery or real-time FPS. The normal game source was not edited.

The separate input-drop negative control is expected to FAIL: movement/collection/
WIN/quit checks reject a running but undriven game. Its FAIL is grader calibration,
not an additional failure of the positive generated game.

Actual screenshots were visually reviewed. Foreground graphics have obvious white
background boxes. The normal pet looks like a fox, while its happy image looks like
a different purple creature. The reaction occurs, but identity/compositing consistency
is poor. Functional 17/17 does not certify finished visual quality. See the initial,
early_feed, feed_win and reset_3 PNGs, plus asset_pixel_audit.json.

## Godot: confirmed resource-identity startup failure

The Build used 418517 input and 32800 output tokens (451317 total), exhausting the
450000 cumulative-token budget after 32 calls. It did not deliver a ready game.

Independent native import succeeds, but actual startup raises:
`Invalid assignment ... position ... Vector3 ... CanvasLayer (hud.gd)` in main.gd:86.
The supposed Orb instance is a HUD. The original live scene contains /Orbs/HUD,
no actual orb Area3D instances, and duplicate HUD labels. A real screenshot is saved.

The main scene's external Orb and HUD references share one UID; the Orb reference's
UID also disagrees with the actual orb.tscn header. In a SEPARATE diagnostic copy,
removing external-resource UID attributes alone eliminates this startup error and
produces three real Orb Area3D nodes. The original game remains unchanged. This
counterfactual establishes a resource-identity cause; it is not an official fix,
Repair invocation, successful Build or full gameplay acceptance.

The initialization error prevents later object setup. Full movement, collection,
win/loss, resets, Escape and cross-frame-rate behavior are NOT_RUN on the original
failed output. Static review also finds `_process()` returning on game_over before
processing R/Escape; terminal-state reset/quit is therefore a separate likely defect,
not a behavior verified in this blocked run.

The upstream procedural manifest says validation=false with errors=[] because its
validator requires a non-empty asset list. The scenario intentionally has no image
assets. Preserve this inconsistency as an upstream status issue; it is not proof of
a failed image request, and no image request was made for this case.

An initial observer setup attempt failed while reading UTF-8 JSON as Windows GBK;
it launched no game. Its INFRA_ERROR is retained in external_play/. After fixing
only observer decoding, external_play_v2/ records the real game startup error.
Do not attribute the observer setup error to the generated game.

## What to improve next (analysis only; no production edits)

1. Validate external UID/path consistency and instantiated scene roles, not only
   resource existence/TSCN syntax. Prefer generated references without fabricated UIDs.
2. Tie action promises and terminal states to behavior checks: real defense effects,
   final HP display, R/Escape before outcome freeze branches, and fresh reset state.
3. Reduce repeated patch misses/read cycles; retain exact current excerpts and use
   a different edit strategy after repeated misses. Extra budget alone does not fix
   a wrong scene identity or inconsistent mechanics.
4. Require consistent normal/happy asset identity and compositing/transparency review;
   file existence and correct PNG dimensions do not establish usable visual assets.

## Cost, limits and reproducibility

Current production defaults were recorded explicitly: Flash model, 40 steps,
1800 seconds, 450000 cumulative tokens, 16384 output-token cap. The external test
adds a USD 0.40 Coder reservation guard per case and at most eight image POSTs.
No case was retried to select a better sample. All actual calls/errors are retained.

Planner and Coder charges were independently reconciled using generation metadata.
Image costs come from successful response usage.cost and lack generation IDs for
independent lookup. summary.json separates the confidence of these amounts. Zero
image calls in Terminal/Godot mean zero image-generation charge, not missing cost.

Physical keyboard, complete human play and Godot cross-FPS verification are NOT_RUN.
This test does not compare Baseline 01, establish a general first-build success rate,
or authorize a new release. The handoff source remains byte-identical.

## Saved files

Every case preserves spec.txt, complete plans/ (raw Planner Plan, Coder view, manifest
and manual where produced), asset_outputs/, full original game/, traces/, native
logs, actual usage/billing and functional observations. Terminal includes each input
and stdout transcript. Pygame includes positive/negative observations and screenshots.
Godot includes original startup screenshot/error and the separate UID control diff.

Use each case's PLAY.md to launch an existing game without model calls. Godot is a
failed debug artifact. `scripts/` preserves external test orchestration; it relies
on the developer workspace's evaluation/native backend, not a standalone test SDK.
MANIFEST.sha256.json seals the saved evidence. No API keys or .env files are included.

## Actual reported cost

| Case | Planner + Coder (independently verified USD) | Images (response-reported USD) | Total reported USD |
|---|---:|---:|---:|
| terminal | 0.07432878 | 0.00000000 | 0.07432878 |
| pygame | 0.02309588 | 0.19386550 | 0.21696138 |
| godot | 0.15218064 | 0.00000000 | 0.15218064 |

Total reported: **USD 0.44347080**. Image amounts are not independently billing-audited.
