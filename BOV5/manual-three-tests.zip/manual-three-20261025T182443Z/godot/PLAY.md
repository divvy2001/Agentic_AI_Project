# Saved game

This original output FAILED Initial Build. It is preserved for diagnosis, not a passed reference game.

Open game/project.godot in Godot 4 to reproduce the startup error.

Read spec.txt, plans/coder_plan.json, plans/play_manual.json (if present), build_result.json and gameplay_checks.json.
No API key is needed to play existing Python game files. Never treat this as permission to launch a new paid Build.
