
extends Area3D

signal collected

func _on_body_entered(body):
	if body.name == "Player":
		emit_signal("collected")
		queue_free()

func connect_signal(signal_name: String, callable: Callable):
	if signal_name == "collected":
		collected.connect(callable)
