
extends CanvasLayer

@onready var orb_count_label = $OrbCountLabel
@onready var controls_label = $ControlsLabel
@onready var status_label = $StatusLabel

func update_orb_count(count: int):
	orb_count_label.text = "Orbs: %d" % count

func show_controls():
	controls_label.visible = true

func hide_controls():
	controls_label.visible = false

func show_status(status_text: String):
	status_label.text = status_text
	status_label.visible = true

func hide_status():
	status_label.visible = false
