extends Area3D

signal reached

var unlocked: bool = false
@onready var mesh_instance = $MeshInstance3D
@onready var collision_shape = $CollisionShape3D

func _ready():
	reset_exit()

func unlock():
	unlocked = true
	var material = StandardMaterial3D.new()
	material.albedo_color = Color(0, 1, 0, 1) # Green color
	mesh_instance.material_override = material
	collision_shape.set_deferred("disabled", false) # Enable collision

func reset_exit():
	unlocked = false
	var material = StandardMaterial3D.new()
	material.albedo_color = Color(0.5, 0.5, 0.5, 1) # Grey color
	mesh_instance.material_override = material
	collision_shape.set_deferred("disabled", true) # Disable collision initially

func _on_body_entered(body):
	if body.name == "Player" and unlocked:
		emit_signal("reached")

func connect_signal(signal_name: String, callable: Callable):
	if signal_name == "reached":
		reached.connect(callable)
