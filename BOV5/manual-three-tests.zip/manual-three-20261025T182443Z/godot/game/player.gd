
extends CharacterBody3D

@export var speed: float = 10.0
var movement_enabled: bool = true

func _physics_process(delta):
	if not movement_enabled:
		return

	var input_dir = Vector3.ZERO
	if Input.is_action_pressed("move_forward"):
		input_dir.z -= 1
	if Input.is_action_pressed("move_backward"):
		input_dir.z += 1
	if Input.is_action_pressed("move_left"):
		input_dir.x -= 1
	if Input.is_action_pressed("move_right"):
		input_dir.x += 1

	var direction = (transform.basis * input_dir).normalized()
	if direction:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)

	move_and_slide()

func set_movement_enabled(enable: bool):
	movement_enabled = enable
	if not enable:
		velocity = Vector3.ZERO
