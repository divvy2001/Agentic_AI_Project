extends Node3D

@export var player_scene: PackedScene
@export var orb_scene: PackedScene
@export var hazard_scene: PackedScene
@export var exit_scene: PackedScene

@onready var hud = $HUD
@onready var player = $Player
@onready var exit = $Exit
@onready var hazard = $Hazard
@onready var orbs_node = $Orbs

var player_start_position: Vector3
var collected_orbs = 0
var game_over = false

func _ready():
	print("Game started")
	player_start_position = player.position
	hud.show_controls()
	_setup_input_actions()
	_reset_game_state()

func _setup_input_actions():
	_add_action_event("move_forward", KEY_W)
	_add_action_event("move_forward", KEY_UP)
	_add_action_event("move_backward", KEY_S)
	_add_action_event("move_backward", KEY_DOWN)
	_add_action_event("move_left", KEY_A)
	_add_action_event("move_left", KEY_LEFT)
	_add_action_event("move_right", KEY_D)
	_add_action_event("move_right", KEY_RIGHT)
	_add_action_event("reset_game", KEY_R)
	_add_action_event("quit_game", KEY_ESCAPE)

func _add_action_event(action_name: String, key_code: Key):
	if not InputMap.has_action(action_name):
		InputMap.add_action(action_name)
	var event = InputEventKey.new()
	event.physical_keycode = key_code
	InputMap.action_add_event(action_name, event)

func _process(delta):
	if game_over:
		return

	if Input.is_action_just_pressed("reset_game"):
		_reset_game()
	if Input.is_action_just_pressed("quit_game"):
		_quit_game()

func _on_orb_collected():
	collected_orbs += 1
	hud.update_orb_count(collected_orbs)
	if collected_orbs >= 3:
		exit.unlock()

func _on_hazard_hit():
	game_over = true
	player.set_movement_enabled(false)
	hud.show_status("LOSE")
	print("LOSE")

func _on_exit_reached():
	game_over = true
	player.set_movement_enabled(false)
	hud.show_status("WIN")
	print("WIN")

func _reset_game_state():
	collected_orbs = 0
	game_over = false
	hud.update_orb_count(collected_orbs)
	hud.hide_status()
	exit.reset_exit()
	player.position = player_start_position
	player.set_movement_enabled(true)

	for child in orbs_node.get_children():
		child.queue_free()

	# Spawn orbs
	var orb1 = orb_scene.instantiate()
	orbs_node.add_child(orb1)
	orb1.position = Vector3(-5, 0.5, -5)
	orb1.connect_signal("collected", Callable(self, "_on_orb_collected"))

	var orb2 = orb_scene.instantiate()
	orbs_node.add_child(orb2)
	orb2.position = Vector3(0, 0.5, 5)
	orb2.connect_signal("collected", Callable(self, "_on_orb_collected"))

	var orb3 = orb_scene.instantiate()
	orbs_node.add_child(orb3)
	orb3.position = Vector3(5, 0.5, -5)
	orb3.connect_signal("collected", Callable(self, "_on_orb_collected"))

	hazard.position = Vector3(0, 0.5, 0)
	hazard.connect_signal("hit", Callable(self, "_on_hazard_hit"))

	exit.position = Vector3(8, 0.5, 8)
	exit.connect_signal("reached", Callable(self, "_on_exit_reached"))

func _reset_game():
	get_tree().reload_current_scene()

func _quit_game():
	get_tree().quit()
