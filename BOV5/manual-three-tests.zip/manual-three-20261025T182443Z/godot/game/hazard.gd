
extends Area3D

signal hit

@onready var mesh_instance = $MeshInstance3D

func _ready():
	var material = StandardMaterial3D.new()
	material.albedo_color = Color(1, 0, 0, 1) # Red color
	mesh_instance.material_override = material

func _on_body_entered(body):
	if body.name == "Player":
		emit_signal("hit")

func connect_signal(signal_name: String, callable: Callable):
	if signal_name == "hit":
		hit.connect(callable)
