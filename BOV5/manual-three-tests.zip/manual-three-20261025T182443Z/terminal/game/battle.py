import random

class Battle:
    def __init__(self, player_monster, opponent_monster):
        self.player_monster = player_monster
        self.opponent_monster = opponent_monster
        self.game_over = False

    def _calculate_damage(self, attacker, defender, is_special=False):
        base_damage = attacker.attack * 2 if is_special else attacker.attack
        return base_damage

    def player_turn(self, action):
        message = ""
        if self.game_over:
            return "Game is over. No more actions.", False

        player_defending = False
        if action == 'attack':
            damage = self._calculate_damage(self.player_monster, self.opponent_monster)
            self.opponent_monster.take_damage(damage)
            message = f"{self.player_monster.name} attacks {self.opponent_monster.name} for {damage} damage!"
        elif action == 'defend':
            player_defending = True
            message = f"{self.player_monster.name} defends, halving incoming damage next turn."
        elif action == 'special':
            if self.player_monster.use_special():
                damage = self._calculate_damage(self.player_monster, self.opponent_monster, is_special=True)
                self.opponent_monster.take_damage(damage)
                message = f"{self.player_monster.name} uses a special move on {self.opponent_monster.name} for {damage} damage!"
            else:
                message = f"{self.player_monster.name} tried to use a special move, but has no uses left!"
        self._check_game_over()
        return message, player_defending

    def opponent_turn(self, player_defending=False):
        message = ""
        if self.game_over:
            return "Game is over. No more actions."

        available_actions = ['attack', 'defend']
        if self.opponent_monster.special_uses > 0:
            available_actions.append('special')

        action = random.choice(available_actions)

        if action == 'attack':
            damage = self._calculate_damage(self.opponent_monster, self.player_monster)
            if player_defending:
                damage //= 2
                message += f" (Player was defending, damage halved!)"
            self.player_monster.take_damage(damage)
            message = f"{self.opponent_monster.name} attacks {self.player_monster.name} for {damage} damage!" + message
        elif action == 'defend':
            message = f"{self.opponent_monster.name} defends, halving incoming damage next turn."
        elif action == 'special':
            if self.opponent_monster.use_special():
                damage = self._calculate_damage(self.opponent_monster, self.player_monster, is_special=True)
                if player_defending:
                    damage //= 2
                    message += f" (Player was defending, damage halved!)"
                self.player_monster.take_damage(damage)
                message = f"{self.opponent_monster.name} uses a special move on {self.player_monster.name} for {damage} damage!" + message
            else:
                message = f"{self.opponent_monster.name} tried to use a special move, but has no uses left! It attacks instead."
                damage = self._calculate_damage(self.opponent_monster, self.player_monster)
                if player_defending:
                    damage //= 2
                    message += f" (Player was defending, damage halved!)"
                self.player_monster.take_damage(damage)
                message = f"{self.opponent_monster.name} attacks {self.player_monster.name} for {damage} damage!" + message
        self._check_game_over()
        return message

    def _check_game_over(self):
        if self.player_monster.hp <= 0 or self.opponent_monster.hp <= 0:
            self.game_over = True

    def is_game_over(self):
        return self.game_over

    def get_winner(self):
        if self.game_over:
            if self.player_monster.hp <= 0:
                return self.opponent_monster.name
            else:
                return self.player_monster.name
        return None

    def display_stats(self):
        return f"""--- Current Stats ---\nPlayer: {self.player_monster}\nOpponent: {self.opponent_monster}\n---------------------"""

    def reset(self):
        self.player_monster.reset()
        self.opponent_monster.reset()
        self.game_over = False
