import sys
import os
import random
import time

# Add the game directory to the Python path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from monster import Monster
from battle import Battle

def _get_player_input(prompt, valid_inputs, is_physical_key=False):
    while True:
        try:
            if sys.stdin.isatty() and is_physical_key:
                import msvcrt
                print(prompt, end='', flush=True)
                key = msvcrt.getwch()
                if key == '\x00' or key == '\xe0':  # Special keys
                    key = msvcrt.getwch()
                    if key == 'H': # Up arrow
                        user_input = 'up'
                    elif key == 'P': # Down arrow
                        user_input = 'down'
                    elif key == 'K': # Left arrow
                        user_input = 'left'
                    elif key == 'M': # Right arrow
                        user_input = 'right'
                    else:
                        user_input = '' # Ignore other special keys
                else:
                    user_input = key.lower()
                print(user_input)
            else:
                user_input = input(prompt).strip().lower()

            if user_input == 'quit':
                sys.exit(0)

            if user_input in valid_inputs:
                return user_input
            else:
                print(f"Invalid input. Please choose from {valid_inputs}.")
        except EOFError:
            print("EOF received. Exiting game.")
            sys.exit(0)
        except Exception as e:
            print(f"An error occurred: {e}")

def main():
    print("Welcome to Terminal Monster Battle!")

    monsters = [
        Monster("Ignis", 100, 20, 2),  # High attack, moderate HP, 2 special uses
        Monster("Aqua", 120, 15, 3),   # High HP, moderate attack, 3 special uses
        Monster("Terra", 110, 18, 2)  # Balanced, 2 special uses
    ]

    while True:
        print("\nChoose your monster:")
        for i, monster in enumerate(monsters):
            print(f"{i + 1}. {monster.name} (HP: {monster.hp}, Attack: {monster.attack}, Special Uses: {monster.special_uses})")

        choice = _get_player_input("Enter the number of your monster (1-3) or 'quit': ", [str(i + 1) for i in range(len(monsters))] + ['quit'])

        if choice == 'quit':
            break

        player_monster = monsters[int(choice) - 1]
        opponent_monster = random.choice([m for m in monsters if m != player_monster])

        print(f"\nYou chose {player_monster.name}. Your opponent is {opponent_monster.name}!")
        battle = Battle(player_monster, opponent_monster)

        while not battle.is_game_over():
            print(battle.display_stats())
            player_action = _get_player_input("\nChoose your action (attack, defend, special) or 'quit': ", ['attack', 'defend', 'special', 'quit'])

            if player_action == 'quit':
                break

            player_message, player_defending = battle.player_turn(player_action)
            print(player_message)

            if battle.is_game_over():
                break

            opponent_message = battle.opponent_turn(player_defending)
            print(opponent_message)

        if battle.is_game_over():
            winner = battle.get_winner()
            if winner == player_monster.name:
                print("\nWIN")
            else:
                print("\nLOSE")
            print(f"{winner} won the battle!")

        play_again = _get_player_input("\nPlay again? (y/n) or 'quit': ", ['y', 'n', 'quit'])
        if play_again == 'n' or play_again == 'quit':
            break
        else:
            battle.reset()
            for monster in monsters:
                monster.reset() # Ensure all monsters are reset for new game
            # _clear_screen() # Removed due to sandbox limitations

    print("Thanks for playing!")

if __name__ == "__main__":
    main()
