class Monster:
    def __init__(self, name, hp, attack, special_uses):
        self.name = name
        self.hp = hp
        self.attack = attack
        self.special_uses = special_uses
        self.max_hp = hp
        self.max_special_uses = special_uses

    def take_damage(self, damage):
        actual_damage = min(damage, self.hp)
        self.hp -= actual_damage
        if self.hp < 0:
            self.hp = 0
        return actual_damage

    def use_special(self):
        if self.special_uses > 0:
            self.special_uses -= 1
            return True
        return False

    def reset(self):
        self.hp = self.max_hp
        self.special_uses = self.max_special_uses

    def __str__(self):
        return f"{self.name} (HP: {self.hp}/{self.max_hp}, Special: {self.special_uses}/{self.max_special_uses})"
