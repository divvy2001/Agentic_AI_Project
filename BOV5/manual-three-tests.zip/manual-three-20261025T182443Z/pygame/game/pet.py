
import pygame
from pathlib import Path
from game.constants import PET_NORMAL_ASSET, PET_HAPPY_ASSET

class Pet(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.normal_image = pygame.image.load(Path(__file__).resolve().parent.parent / PET_NORMAL_ASSET).convert_alpha()
        self.happy_image = pygame.image.load(Path(__file__).resolve().parent.parent / PET_HAPPY_ASSET).convert_alpha()
        self.image = self.normal_image
        self.rect = self.image.get_rect(center=(x, y))

    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def set_happy(self):
        self.image = self.happy_image

    def set_normal(self):
        self.image = self.normal_image

    def get_rect(self):
        return self.rect

    def reset(self):
        self.set_normal()
