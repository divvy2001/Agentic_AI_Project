
import pygame
from pathlib import Path
from game.constants import PLAYER_ASSET, PLAYER_SPEED, SCREEN_WIDTH, SCREEN_HEIGHT

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        asset_path = Path(__file__).resolve().parent.parent / PLAYER_ASSET
        self.image = pygame.image.load(asset_path).convert_alpha()
        self.rect = self.image.get_rect(center=(x, y))
        self.initial_position = (x, y)

    def update(self, keys, dt):
        if keys[pygame.K_w] or keys[pygame.K_UP]:
            self.rect.y -= PLAYER_SPEED * dt
        if keys[pygame.K_s] or keys[pygame.K_DOWN]:
            self.rect.y += PLAYER_SPEED * dt
        if keys[pygame.K_a] or keys[pygame.K_LEFT]:
            self.rect.x -= PLAYER_SPEED * dt
        if keys[pygame.K_d] or keys[pygame.K_RIGHT]:
            self.rect.x += PLAYER_SPEED * dt

        # Keep player on screen
        self.rect.left = max(0, self.rect.left)
        self.rect.right = min(SCREEN_WIDTH, self.rect.right)
        self.rect.top = max(0, self.rect.top)
        self.rect.bottom = min(SCREEN_HEIGHT, self.rect.bottom)

    def draw(self, screen):
        screen.blit(self.image, self.rect)

    def get_rect(self):
        return self.rect

    def reset(self):
        self.rect.center = self.initial_position
