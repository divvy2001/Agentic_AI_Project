
import pygame
from game.constants import WHITE, BLACK, FONT_SIZE, WIN_FONT_SIZE, SCREEN_WIDTH, SCREEN_HEIGHT

class UI:
    def __init__(self):
        pygame.font.init()
        self.font = pygame.font.Font(None, FONT_SIZE)
        self.win_font = pygame.font.Font(None, WIN_FONT_SIZE)

    def draw_apple_counter(self, screen, count):
        text_surface = self.font.render(f"Apples: {count}", True, BLACK)
        screen.blit(text_surface, (10, 10))

    def draw_controls(self, screen):
        controls_text = [
            "Move: WASD or Arrow Keys",
            "Feed Pet: E (after 3 apples)",
            "Reset: R",
            "Quit: Escape"
        ]
        for i, line in enumerate(controls_text):
            text_surface = self.font.render(line, True, BLACK)
            screen.blit(text_surface, (10, 40 + i * 20))

    def draw_win_message(self, screen):
        win_text = self.win_font.render("WIN!", True, (0, 128, 0)) # Darker green for WIN
        text_rect = win_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
        screen.blit(win_text, text_rect)
