
import pygame

# Screen dimensions
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)

# Game settings
FPS = 60
PLAYER_SPEED = 200 # Pixels per second
APPLE_COUNT_TO_WIN = 3

# Font settings
FONT_SIZE = 24
WIN_FONT_SIZE = 48

# Asset paths (relative to the game/ directory)
PLAYER_ASSET = "game/assets/player_character.png"
PET_NORMAL_ASSET = "game/assets/pet_normal.png"
PET_HAPPY_ASSET = "game/assets/pet_happy.png"
APPLE_ASSET = "game/assets/apple.png"
BACKGROUND_ASSET = "game/assets/garden_background.png"
