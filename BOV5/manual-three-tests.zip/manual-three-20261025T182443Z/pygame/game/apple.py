
import pygame
from pathlib import Path
from game.constants import APPLE_ASSET

class Apple(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        asset_path = Path(__file__).resolve().parent.parent / APPLE_ASSET
        self.image = pygame.image.load(asset_path).convert_alpha()
        self.rect = self.image.get_rect(center=(x, y))
        self.visible = True
        self.initial_position = (x, y)

    def draw(self, screen):
        if self.visible:
            screen.blit(self.image, self.rect)

    def collect(self):
        self.visible = False

    def is_visible(self):
        return self.visible

    def get_rect(self):
        return self.rect

    def reset(self):
        self.visible = True
        self.rect.center = self.initial_position
