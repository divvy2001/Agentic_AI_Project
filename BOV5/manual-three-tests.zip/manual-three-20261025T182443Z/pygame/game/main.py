
import pygame
import sys
import os
from pathlib import Path

# Add the game directory to the Python path for module imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from game.constants import (
    SCREEN_WIDTH, SCREEN_HEIGHT, FPS, BACKGROUND_ASSET, WHITE, APPLE_COUNT_TO_WIN
)
from game.player import Player
from game.pet import Pet
from game.apple import Apple
from game.ui import UI

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Pixel Pet Garden")
        self.clock = pygame.time.Clock()
        self.running = True
        self.win_state = False

        self.background = self._load_background()
        self.player = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50)
        self.pet = Pet(SCREEN_WIDTH // 2, 100)
        self.apples = self._create_apples()
        self.collected_apples = 0
        self.ui = UI()

    def _load_background(self):
        asset_path = Path(__file__).resolve().parent.parent / BACKGROUND_ASSET
        background_image = pygame.image.load(asset_path).convert()
        return pygame.transform.scale(background_image, (SCREEN_WIDTH, SCREEN_HEIGHT))

    def _create_apples(self):
        # Place apples in distinct locations
        return [
            Apple(150, 200),
            Apple(SCREEN_WIDTH - 150, 250),
            Apple(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50)
        ]

    def _handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                if event.key == pygame.K_r:
                    self.reset_game()
                if event.key == pygame.K_e and not self.win_state:
                    if self.collected_apples >= APPLE_COUNT_TO_WIN and self.player.get_rect().colliderect(self.pet.get_rect()):
                        self.win_state = True
                        self.pet.set_happy()

    def _update_game_state(self, dt):
        if not self.win_state:
            keys = pygame.key.get_pressed()
            self.player.update(keys, dt)

            for apple in self.apples:
                if apple.is_visible() and self.player.get_rect().colliderect(apple.get_rect()):
                    apple.collect()
                    self.collected_apples += 1
                    print(f"[EVENT] SCORE:{self.collected_apples}")
                    if self.collected_apples >= APPLE_COUNT_TO_WIN:
                        print("[EVENT] All apples collected!")

    def _draw(self):
        self.screen.blit(self.background, (0, 0))
        self.player.draw(self.screen)
        self.pet.draw(self.screen)
        for apple in self.apples:
            apple.draw(self.screen)
        self.ui.draw_apple_counter(self.screen, self.collected_apples)
        self.ui.draw_controls(self.screen)
        if self.win_state:
            self.ui.draw_win_message(self.screen)

        pygame.display.flip()

    def reset_game(self):
        self.player.reset()
        self.pet.reset()
        for apple in self.apples:
            apple.reset()
        self.collected_apples = 0
        self.win_state = False
        print("[EVENT] Game reset.")

    def run(self):
        print("[EVENT] Game started.")
        while self.running:
            dt = self.clock.tick(FPS) / 1000.0  # Delta time in seconds
            self._handle_input()
            self._update_game_state(dt)
            self._draw()

        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = Game()
    game.run()
