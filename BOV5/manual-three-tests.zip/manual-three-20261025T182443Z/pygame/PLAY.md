# Saved game

From this case directory, activate the configured Python environment and run:

```powershell
python -m game.main
```

Read spec.txt, plans/coder_plan.json, plans/play_manual.json (if present), build_result.json and gameplay_checks.json.
No API key is needed to play existing Python game files. Never treat this as permission to launch a new paid Build.
