class_name Ball
extends Node2D

@export var g: float = 900.0 # pixels/s^2 gravity for projectile and pendulum

var attached: bool = true
var released: bool = false
var anchor_pos: Vector2 = Vector2.ZERO
var length: float = 300.0
var angle: float = -0.9 # measured from vertical, negative = left
var ang_vel: float = 0.0
var linear_velocity: Vector2 = Vector2.ZERO

var sprite: Sprite2D = null

func _ready() -> void:
    sprite = get_node_or_null("Sprite") as Sprite2D
    if sprite:
        sprite.centered = true

func reset(p_anchor: Vector2, p_length: float) -> void:
    anchor_pos = p_anchor
    length = p_length
    attached = true
    released = false
    angle = -0.9
    ang_vel = 0.0
    linear_velocity = Vector2.ZERO
    # Ensure sprite reference (in case reset is called before _ready)
    if not sprite:
        sprite = get_node_or_null("Sprite") as Sprite2D
    global_position = anchor_pos + Vector2(sin(angle), cos(angle)) * length
    if sprite:
        sprite.visible = true

func release() -> void:
    if not attached:
        return
    attached = false
    released = true
    # linear velocity from angular velocity: v = length * ang_vel perpendicular to radius
    linear_velocity = length * Vector2(cos(angle), -sin(angle)) * ang_vel

func _process(delta: float) -> void:
    if attached:
        var ang_acc: float = -(g / length) * sin(angle)
        ang_vel += ang_acc * delta
        angle += ang_vel * delta
        global_position = anchor_pos + Vector2(sin(angle), cos(angle)) * length
    else:
        linear_velocity.y += g * delta
        global_position += linear_velocity * delta
