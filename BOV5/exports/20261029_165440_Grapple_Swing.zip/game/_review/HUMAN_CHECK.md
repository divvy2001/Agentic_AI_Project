# Human check: Grapple Swing (20261029_165440)

Play the game (double-click play.bat in the gallery, or `python play.py` in BOV5), then fill this in.
It is the ground truth for comparing against the automated Tester result: **STOPPED: coder did not finish**

| Question | Answer (yes / no / partly) | Notes |
|---|---|---|
| Game launches without errors | | |
| Every control does what the manual says | | |
| Main mechanic works (scoring, collisions, enemies...) | | |
| Win / game over / restart work | | |
| Looks right (sprites, layout, text readable) | | |

**Overall verdict** (works / partly works / broken): 

**Do the automated test results match what you saw?** (yes / no: which test was wrong?):
