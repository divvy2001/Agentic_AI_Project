extends Node2D

@onready var viewport_size: Vector2 = get_viewport_rect().size

const BALL_SCENE: PackedScene = preload("res://ball.tscn")

var score: int = 0
var anchor_pos: Vector2
var pendulum_length: float = 220.0
var target_rect: Rect2
var ball: Node = null
var score_label: Label = null

func _ready() -> void:
    # Input actions
    if not InputMap.has_action("release"):
        InputMap.add_action("release")
        var ev := InputEventKey.new()
        ev.keycode = KEY_SPACE
        InputMap.action_add_event("release", ev)
    if not InputMap.has_action("restart"):
        InputMap.add_action("restart")
        var ev2 := InputEventKey.new()
        ev2.keycode = KEY_R
        InputMap.action_add_event("restart", ev2)
    if not InputMap.has_action("quit"):
        InputMap.add_action("quit")
        var ev3 := InputEventKey.new()
        ev3.keycode = KEY_ESCAPE
        InputMap.action_add_event("quit", ev3)

    anchor_pos = Vector2(viewport_size.x / 2, 80)
    target_rect = Rect2(Vector2(viewport_size.x/2 - 80, viewport_size.y - 120), Vector2(160, 80))

    # Create a Label to show score in top-left
    score_label = Label.new()
    score_label.text = "Score: %d" % score
    score_label.position = Vector2(8, 8)
    add_child(score_label)

    spawn_ball()
    set_process(true)

func spawn_ball() -> void:
    if ball:
        ball.queue_free()
    ball = BALL_SCENE.instantiate()
    add_child(ball)
    ball.reset(anchor_pos, pendulum_length)

func _process(delta: float) -> void:
    # Input handling
    if Input.is_action_just_pressed("release") and ball and ball.attached:
        ball.release()
        print("RELEASE")
    if Input.is_action_just_pressed("restart"):
        score = 0
        score_label.text = "Score: %d" % score
        spawn_ball()
        print("RESTART")
    if Input.is_action_just_pressed("quit"):
        print("QUIT")
        get_tree().quit()

    # Landing and scoring checks
    if ball and ball.released:
        var center: Vector2 = ball.global_position
        if target_rect.has_point(center):
            score += 1
            score_label.text = "Score: %d" % score
            print("SCORE")
            spawn_ball()
        elif center.y > viewport_size.y:
            # missed
            spawn_ball()

    # Request redraw for rope/target/anchor visuals
    queue_redraw()

func _draw() -> void:
    # Draw anchor
    draw_circle(anchor_pos, 6, Color(1,0,0))
    # Draw rope if attached
    if ball and ball.attached:
        draw_line(anchor_pos, ball.global_position, Color(0.6,0.6,0.6), 3)
    # Draw target
    draw_rect(target_rect, Color(0,1,0))
