class_name Car
extends CharacterBody2D

@export var accel: float = 800.0
@export var max_speed: float = 400.0
@export var brake_force: float = 1200.0
@export var friction: float = 300.0
@export var turn_speed: float = 2.5 # radians per second base
@export var align_speed: float = 3.0 # how quickly velocity aligns to facing (drift behavior)

var vel: Vector2 = Vector2.ZERO
var start_pos: Vector2
var start_rot: float

func _ready() -> void:
    start_pos = global_position
    start_rot = rotation
    add_to_group("car")

    # Ensure input actions exist and have at least one key
    if not InputMap.has_action("ui_up"):
        InputMap.add_action("ui_up")
    var ev = InputEventKey.new()
    ev.physical_keycode = KEY_UP
    InputMap.action_add_event("ui_up", ev)

    if not InputMap.has_action("ui_down"):
        InputMap.add_action("ui_down")
    ev = InputEventKey.new()
    ev.physical_keycode = KEY_DOWN
    InputMap.action_add_event("ui_down", ev)

    if not InputMap.has_action("ui_left"):
        InputMap.add_action("ui_left")
    ev = InputEventKey.new()
    ev.physical_keycode = KEY_LEFT
    InputMap.action_add_event("ui_left", ev)

    if not InputMap.has_action("ui_right"):
        InputMap.add_action("ui_right")
    ev = InputEventKey.new()
    ev.physical_keycode = KEY_RIGHT
    InputMap.action_add_event("ui_right", ev)

    if not InputMap.has_action("restart"):
        InputMap.add_action("restart")
    ev = InputEventKey.new()
    ev.physical_keycode = KEY_R
    InputMap.action_add_event("restart", ev)

    if not InputMap.has_action("quit"):
        InputMap.add_action("quit")
    ev = InputEventKey.new()
    ev.physical_keycode = KEY_ESCAPE
    InputMap.action_add_event("quit", ev)

func _physics_process(delta: float) -> void:
    var forward: Vector2 = Vector2.RIGHT.rotated(rotation)

    # Input prints on just_pressed
    if Input.is_action_just_pressed("ui_up"):
        print("ACCELERATE")
    if Input.is_action_just_pressed("ui_down"):
        print("BRAKE")
    if Input.is_action_just_pressed("ui_left"):
        print("TURN LEFT")
    if Input.is_action_just_pressed("ui_right"):
        print("TURN RIGHT")
    if Input.is_action_just_pressed("restart"):
        print("RESTART")
        var t = get_parent().get_node_or_null("Track")
        if t:
            t.reset()
        reset()
    if Input.is_action_just_pressed("quit"):
        print("QUIT")
        get_tree().quit()

    # Acceleration / braking
    var is_acc = Input.is_action_pressed("ui_up")
    var is_brake = Input.is_action_pressed("ui_down")

    if is_acc and not is_brake:
        vel += forward * accel * delta
    elif is_brake and not is_acc:
        vel -= forward * accel * delta
    else:
        # apply friction toward zero
        vel = vel.move_toward(Vector2.ZERO, friction * delta)

    # Limit max speed (based on absolute speed)
    if vel.length() > max_speed:
        vel = vel.normalized() * max_speed

    # Steering affects rotation; scaled by speed to feel car-like
    var steer: float = 0.0
    if Input.is_action_pressed("ui_left"):
        steer -= 1.0
    if Input.is_action_pressed("ui_right"):
        steer += 1.0

    if steer != 0.0:
        # steering scaled by current speed fraction so low-speed turning still possible
        var speed_factor = clamp(vel.length() / max_speed, 0.0, 1.0)
        rotation += steer * turn_speed * (0.2 + speed_factor) * delta

    # Drift: don't instantly align velocity to facing. Gradually lerp velocity direction toward facing direction
    if vel.length() > 0.01:
        var target = forward * vel.length()
        var align_factor = align_speed * delta
        vel = vel.lerp(target, align_factor)

    # Move and collide; collision with walls stops forward momentum
    var collision = move_and_collide(vel * delta)
    if collision:
        # Stop movement on collision
        vel = Vector2.ZERO

func reset(start_pos_in = null, start_rot_in = null) -> void:
    if start_pos_in != null:
        global_position = start_pos_in
    else:
        global_position = start_pos
    if start_rot_in != null:
        rotation = start_rot_in
    else:
        rotation = start_rot
    vel = Vector2.ZERO
