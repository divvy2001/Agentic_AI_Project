class_name Track
extends Node2D

signal lap_completed(new_count: int)

var lap_count: int = 0
var passed_checkpoint: bool = false

# resolve children at runtime to avoid instantiation order issues
var start_line: Area2D = null
var checkpoint: Area2D = null

func _ready() -> void:
    lap_count = 0
    passed_checkpoint = false
    start_line = get_node_or_null("StartLine") as Area2D
    checkpoint = get_node_or_null("Checkpoint") as Area2D
    if start_line:
        start_line.body_entered.connect(_on_start_line_body_entered)
    if checkpoint:
        checkpoint.body_entered.connect(_on_checkpoint_body_entered)

func _on_checkpoint_body_entered(body: Node) -> void:
    if body.is_in_group("car"):
        passed_checkpoint = true

func _on_start_line_body_entered(body: Node) -> void:
    if body.is_in_group("car") and passed_checkpoint:
        lap_count += 1
        passed_checkpoint = false
        emit_signal("lap_completed", lap_count)

func reset() -> void:
    lap_count = 0
    passed_checkpoint = false
    # Notify UI to reset display
    emit_signal("lap_completed", lap_count)
