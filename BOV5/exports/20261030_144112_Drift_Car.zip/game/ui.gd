class_name UI
extends CanvasLayer

var lap_label: Label = null

func _ready() -> void:
    # find the LapLabel under this CanvasLayer; nodes may be instantiated in different order
    lap_label = get_node_or_null("MarginContainer/LapLabel") as Label
    # find Track node in the scene tree
    var root = get_tree().get_root()
    var main = root.get_node_or_null("/root/Main")
    if main:
        var track = main.get_node_or_null("Track")
        if track:
            track.lap_completed.connect(_on_lap_completed)
    _update_label(0)

func _on_lap_completed(new_count: int) -> void:
    print("LAP COMPLETE")
    _update_label(new_count)

func _update_label(count: int) -> void:
    if lap_label:
        lap_label.text = "Laps: %d" % count
