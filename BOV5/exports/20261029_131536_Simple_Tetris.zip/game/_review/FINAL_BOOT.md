# Final boot log: 20261029_131536

command: C:\Users\ASUS\AppData\Local\Programs\Python\Python311\python.exe -u -m game.tetris_game
exit: killed after timeout (normal for a running game)

## stdout
```
pygame 2.6.1 (SDL 2.28.4, Python 3.11.9)
Hello from the pygame community. https://www.pygame.org/contribute.html
RESTART
SCORE:0

```

## stderr
```

```
